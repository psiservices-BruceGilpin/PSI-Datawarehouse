﻿CREATE TABLE [dbo].[BookingCode](
	[TestRegn_ID] [bigint] NOT NULL,
	[Global_Schedule_ID] [varchar](20) NULL,
	[test_id] [int] NULL,
	[external_proctoring_request_id] [varchar](100) NULL
) ON [PRIMARY]