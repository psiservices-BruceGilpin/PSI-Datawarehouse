﻿/****** Object:  Synonym [dbo].[QuarterlyCalendar_vw]    Script Date: 6/19/2023 10:44:19 AM ******/
CREATE SYNONYM [dbo].[QuarterlyCalendar_vw] FOR [psi_reporting].[dbo].[QuarterlyCalendar_vw]