﻿CREATE TABLE [dbo].[ExternalProcIDs](
	[FName] [nvarchar](50) NULL,
	[LName] [nvarchar](50) NULL,
	[TestRegn_ID] [bigint] NOT NULL,
	[external_proctoring_request_id] [varchar](100) NULL
) ON [PRIMARY]