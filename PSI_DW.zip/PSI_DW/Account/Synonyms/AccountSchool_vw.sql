﻿/****** Object:  Synonym [Account].[AccountSchool_vw]    Script Date: 6/19/2023 10:44:18 AM ******/
CREATE SYNONYM [Account].[AccountSchool_vw] FOR [psi_reporting].[account].[accountschool_vw]