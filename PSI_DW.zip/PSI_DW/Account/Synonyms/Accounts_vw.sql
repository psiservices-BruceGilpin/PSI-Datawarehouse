﻿/****** Object:  Synonym [Account].[Accounts_vw]    Script Date: 6/19/2023 10:44:18 AM ******/
CREATE SYNONYM [Account].[Accounts_vw] FOR [psi_reporting].[Account].[Accounts_vw]