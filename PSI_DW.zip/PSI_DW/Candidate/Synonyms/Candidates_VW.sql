﻿/****** Object:  Synonym [Candidate].[Candidates_VW]    Script Date: 6/19/2023 10:44:18 AM ******/
CREATE SYNONYM [Candidate].[Candidates_VW] FOR [psi_reporting].[Candidate].[Candidates_vw]