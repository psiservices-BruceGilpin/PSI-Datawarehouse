﻿/****** Object:  Synonym [Candidate].[TestLaunch_vw]    Script Date: 6/19/2023 10:44:19 AM ******/
CREATE SYNONYM [Candidate].[TestLaunch_vw] FOR [psi_reporting].[Candidate].[TestLaunch]