﻿CREATE SYNONYM [candidate].[Demographics_vw]
	FOR psi_reporting.candidate.demographics_vw
