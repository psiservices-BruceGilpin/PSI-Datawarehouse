﻿CREATE SYNONYM [candidate].[DemographicTypes_vw]
	FOR psi_reporting.candidate.demographictypes_vw
