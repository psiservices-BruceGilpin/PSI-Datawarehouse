﻿/****** Object:  Synonym [Candidate].[Response_Vw]    Script Date: 6/19/2023 10:44:19 AM ******/
CREATE SYNONYM [Candidate].[Response_Vw] FOR [PSI_Reporting].[Candidate].[CandidateResponse_vw]