﻿CREATE SYNONYM [candidate].[CompositeTestPortionScores_vw]
	FOR [PSI_Reporting].candidate.CompositeTestPortionScores_vw
