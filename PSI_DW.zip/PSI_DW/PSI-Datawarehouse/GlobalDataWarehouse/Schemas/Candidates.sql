﻿CREATE SCHEMA [Candidates]
