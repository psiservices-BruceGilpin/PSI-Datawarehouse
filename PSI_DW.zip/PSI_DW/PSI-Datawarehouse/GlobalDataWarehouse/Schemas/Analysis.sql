﻿CREATE SCHEMA [Analysis]
