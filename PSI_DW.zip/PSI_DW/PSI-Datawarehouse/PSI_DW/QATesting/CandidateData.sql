﻿CREATE TABLE [QATesting].[CandidateData](
	[Portion_ID] [float] NULL,
	[Exams] [nvarchar](255) NULL,
	[First Time Pass Rate] [float] NULL,
	[First Time N] [float] NULL,
	[All Candidates Pass Rate] [float] NULL,
	[All Candidates N] [float] NULL
) ON [PRIMARY]