﻿/****** Object:  Synonym [Test].[ItemOptions_vw]    Script Date: 6/19/2023 10:44:20 AM ******/
CREATE SYNONYM [Test].[ItemOptions_vw] FOR [PSI_Reporting].[Test].[ItemOption_Vw]