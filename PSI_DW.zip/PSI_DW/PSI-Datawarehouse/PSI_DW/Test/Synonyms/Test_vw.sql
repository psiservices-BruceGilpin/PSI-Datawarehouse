﻿/****** Object:  Synonym [Test].[Test_vw]    Script Date: 6/19/2023 10:44:21 AM ******/
CREATE SYNONYM [Test].[Test_vw] FOR [PSI_Reporting].[Test].[Tests_vw]