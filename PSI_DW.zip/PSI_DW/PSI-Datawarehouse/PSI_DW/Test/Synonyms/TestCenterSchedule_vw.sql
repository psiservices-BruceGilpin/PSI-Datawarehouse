﻿/****** Object:  Synonym [Test].[TestCenterSchedule_vw]    Script Date: 6/19/2023 10:44:21 AM ******/
CREATE SYNONYM [Test].[TestCenterSchedule_vw] FOR [PSI_Reporting].[Test].[TestCenterSchedule_vw]