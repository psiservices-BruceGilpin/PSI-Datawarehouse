﻿/****** Object:  Synonym [Test].[Item_vw]    Script Date: 6/19/2023 10:44:20 AM ******/
CREATE SYNONYM [Test].[Item_vw] FOR [PSI_Reporting].[Test].[Item_vw]