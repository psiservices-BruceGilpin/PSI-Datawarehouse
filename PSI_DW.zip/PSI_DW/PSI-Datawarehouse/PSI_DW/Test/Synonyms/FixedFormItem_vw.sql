﻿/****** Object:  Synonym [Test].[FixedFormItem_vw]    Script Date: 6/19/2023 10:44:20 AM ******/
CREATE SYNONYM [Test].[FixedFormItem_vw] FOR [PSI_Reporting].[Test].[FixedFormItem_vw]