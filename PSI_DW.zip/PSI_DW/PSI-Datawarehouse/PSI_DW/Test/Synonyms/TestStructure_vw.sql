﻿/****** Object:  Synonym [Test].[TestStructure_vw]    Script Date: 6/19/2023 10:44:21 AM ******/
CREATE SYNONYM [Test].[TestStructure_vw] FOR [psi_reporting].[Test].[TestStructure_vw]