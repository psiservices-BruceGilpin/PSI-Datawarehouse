﻿/****** Object:  Synonym [Test].[TestDefinition_vw]    Script Date: 6/19/2023 10:44:21 AM ******/
CREATE SYNONYM [Test].[TestDefinition_vw] FOR [PSI_Reporting].[test].[TestDefinition_vw]