﻿/****** Object:  Synonym [Test].[Portion_vw]    Script Date: 6/19/2023 10:44:21 AM ******/
CREATE SYNONYM [Test].[Portion_vw] FOR [PSI_Reporting].[Test].[Portion_vw]