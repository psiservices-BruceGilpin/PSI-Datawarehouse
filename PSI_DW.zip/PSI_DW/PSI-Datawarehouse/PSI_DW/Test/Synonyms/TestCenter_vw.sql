﻿/****** Object:  Synonym [Test].[TestCenter_vw]    Script Date: 6/19/2023 10:44:21 AM ******/
CREATE SYNONYM [Test].[TestCenter_vw] FOR [PSI_Reporting].[test].[TestCenter_vw]