﻿/****** Object:  Synonym [Test].[FixedForm_vw]    Script Date: 6/19/2023 10:44:20 AM ******/
CREATE SYNONYM [Test].[FixedForm_vw] FOR [PSI_Reporting].[Test].[FixedForm_Vw]